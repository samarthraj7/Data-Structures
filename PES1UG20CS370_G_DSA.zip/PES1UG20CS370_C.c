#include <stdio.h>
#include <stdlib.h>
#define MAX 10
#include "PES1UG20CS370_H.h"

int main()
{

    FILE *ptr1;
    ptr1 = fopen("input.txt", "r");
    int s_r, s_c, e_r, e_c, arr[50][10];
    fscanf(ptr1, "%d %d", &s_r, &s_c);
    fscanf(ptr1, "%d %d", &e_r, &e_c);
    printf("input.txt\n\n");
    printf("%d %d\t%d %d\n", s_r, s_c, e_r, e_c);
    int i, j;
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 10; j++)
        {
            fscanf(ptr1, "%d", &arr[i][j]);
        }
    }
   
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 10; j++)
        {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }
    printf("\n\n");
    matrix *m = NULL;
    matrix *temp = NULL;
    for (int i = 0; i < 10; i++)
    {
        if (m == NULL)
        {
            m = (matrix *)malloc(sizeof(matrix));
            m->HEAD = NULL;
            m->TAIL = NULL;
            temp = m;
            temp->DOWN = NULL;
            
        }
        else
        {
            temp->DOWN = (matrix *)malloc(sizeof(matrix));
            temp->DOWN->HEAD = NULL;
            temp->DOWN->TAIL = NULL;
            temp->DOWN->DOWN = NULL;
            temp = temp->DOWN;
        }
    }

    readmap(&m, arr);
    
    int r=path_finder(m, s_r, s_c, e_r, e_c);

    if(r==0)
    {
        printf("\nThere is no path ,-1 is stored in \"PES1UG20CS370_O.txt\"\n\n");
    }
    else
    {
        printf("\nOUTPUT IS BEING STORED IN THE FILE NAMED  \"PES1UG20CS370_O.txt\"\n\n");
    }
    return 0;
}