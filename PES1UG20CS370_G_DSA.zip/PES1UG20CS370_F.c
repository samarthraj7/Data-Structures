#include <stdio.h>
#include <stdlib.h>
#include "PES1UG20CS370_H.h"
#define MAX 10
table *new__Node(int i, int j)
{
    table *temp = (table *)malloc(sizeof(table));
    temp->d = NULL;
    temp->r = NULL;
    temp->sr = NULL;
    temp->x = i;
    temp->y = j;
    return temp;
}

table *search__node(matrix *m, int j)
{
    table *q = m->HEAD;
    while (q->y != j && q->sr != NULL)
    {
        q = q->sr;
    }
    if (q->y != j)
    {
        return NULL;
    }
    return q;
}

void readmap(matrix **m, int arr[][10]) 
{
    matrix *p;
    matrix *previous_p;
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (arr[i][j] == 0)
            {
                p = *m;
                previous_p = NULL;
                for (int k = 0; k < i; k++)
                {
                    previous_p = p;
                    p = p->DOWN;
                }
                if (p->HEAD == NULL)
                {
                    p->HEAD = new__Node(i, j);
                    p->TAIL = p->HEAD;
                    if (previous_p != NULL)
                    {

                       
                        table *q = search__node(previous_p, j);
                        if (q != NULL)
                        {

                            q->d = p->TAIL;
                        }
                    }
                }
                else
                {

                    if (p->TAIL->y == j - 1)
                    {

                        p->TAIL->r = new__Node(i, j);
                        p->TAIL->sr = p->TAIL->r;
                        p->TAIL = p->TAIL->r;

                        if (previous_p != NULL)
                        {
                            
                            table *q = search__node(previous_p, j);
                            if (q != NULL)
                            {

                                q->d = p->TAIL;
                                
                            }
                        }
                    }
                    else
                    {

                        p->TAIL->sr = new__Node(i, j);
                        p->TAIL = p->TAIL->sr;

                        if (previous_p != NULL)
                        {
                            table *q = search__node(previous_p, j);
                            if (q != NULL)
                            {
                                q->d = p->TAIL;
                            }
                        }
                    }
                }
            }
        }
    }
}



void push(stack *s, table *p)
{
    if (s->top == MAX - 1)
    {
        printf("stack is full\n");
    }
    else
    {
        s->top++;
        s->a[s->top] = p;
    }
}

table *pop(stack *s)
{
    if (s->top == -1)
    {
        return NULL;
    }
    else
    {
        table *r = s->a[s->top];
        s->top--;
        return r;
    }
}

int find_index(int x, int y, path arr[], int count)
{
    int i = 0;
    while ((arr[i].x != x || arr[i].y != y) && i < count)
    {
        i++;
    }
    return i;
}
int path_finder(matrix *m, int s_r, int s_c, int e_r, int e_c)
{
    matrix *temp = m;
    for (int i = 0; i < s_r; i++)
    {
        temp = temp->DOWN;
    }
    table *r1 = temp->HEAD;
    for (int i = 0; i < s_c; i++)
    {
        r1 = r1->sr;
    }
    stack p;
    p.top = -1;
    table *r2;
    path ar[100];
    int count = 0;
    while (r1->x != e_r || r1->y != e_c)
    {

        if (r1->r == NULL && r1->d != NULL)
        {
            r1 = r1->d;
        }
        else if (r1->d == NULL && r1->r != NULL)
        {

            r1 = r1->r;
        }
        else if (r1->r != NULL && r1->d != NULL)
        {
            if (r1->x == e_r)
            {
                r1 = r1->r;
            }
            else if (r1->y == e_c)
            {
                r1 = r1->d;
            }
            else
            {
                r2 = r1;
                push(&p, r2);
                r1 = r1->r;
            }
        }
        ar[count].x = r1->x;
        ar[count].y = r1->y;
        count++;
        if (r1->r == NULL && r1->d == NULL && (r1->x != e_r || r1->y != e_c))
        {

            r2 = (pop(&p));
            if(r2==NULL)
            {
                break;
            }
            r1 = r2->d;
            count = find_index(r2->x, r2->y, ar, count);
            count++;
            ar[count].x = r1->x;
            ar[count].y = r1->y;
            count++;
        }
        
    }
        
    FILE *ptr2=fopen("PES1UG20CS370_O.txt","w");
        
    if(r1->x != e_r || r1->y != e_c)
    {   
         fprintf(ptr2,"%d\n",-1);
        return 0;
    }
       
    else
    {
        fprintf(ptr2,"%d %d\n",s_r,s_c);;
        for (int i = 0; i < count; i++)
        {
            fprintf(ptr2,"%d %d\n",ar[i].x,ar[i].y);
        }
        return 1;
    }
}
