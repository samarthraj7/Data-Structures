#define MAX 10

typedef struct table
{
    int x, y;
    struct table *r, *d, *sr;
} table;

typedef struct matrix
{
    table *HEAD;
    table *TAIL;
    struct matrix *DOWN;
} matrix;

typedef struct stack
{
    table *a[MAX];
    int top;
} stack;

typedef struct path
{
    int x, y;
} path;




int path_finder(matrix *m, int s_r, int s_c, int e_r, int e_c);
void readmap(matrix **m, int arr[][10]);